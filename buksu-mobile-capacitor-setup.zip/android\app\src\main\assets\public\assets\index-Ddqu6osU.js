const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DYUR6MhW.js","assets/index-CcXeKaPj.js","assets/index-fxUp13jM.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CcXeKaPj.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-DYUR6MhW.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
